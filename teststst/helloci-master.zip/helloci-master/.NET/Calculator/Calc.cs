﻿namespace Calculator
{
    public static class Calc
    {
        public static int Sum(int a, int b) => a + b;

        public static int Substract(int a, int b) => a - b;

        public static int Multiply(int a, int b) => a * b;

        public static int Devide(int a, int b) => a / b;
    }
}
