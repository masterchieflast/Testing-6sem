﻿namespace CalculatorTest
{
    public class Config
    {
        public string BrowserName { get; set; }

        public int TimeoutSeconds { get; set; }
    }
}
