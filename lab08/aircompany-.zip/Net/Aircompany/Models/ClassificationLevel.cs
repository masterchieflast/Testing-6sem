﻿namespace Aircompany.Models
{
    public enum ClassificationLevel
    {
        UNCLASSIFIED,
        CONFIDENTIAL,
        SECRET,
        TOP_SECRET
    }
}
